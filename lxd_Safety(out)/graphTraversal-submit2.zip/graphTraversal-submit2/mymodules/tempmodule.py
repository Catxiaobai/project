def fun():
    for i in range(100):
        print i,
