f = open("../model/target.txt", 'r')
targetList=[]
targetList = f.readlines()
f.close()